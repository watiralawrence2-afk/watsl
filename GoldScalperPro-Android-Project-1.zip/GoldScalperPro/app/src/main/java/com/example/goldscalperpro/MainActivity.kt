package com.example.goldscalperpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DemoTrade(val id: Int, val side: String, val entry: Double, val openedAt: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GoldScalperScreen() } }
    }
}

@Composable
fun GoldScalperScreen() {
    var running by remember { mutableStateOf(false) }
    var price by remember { mutableDoubleStateOf(2350.00) }
    var balance by remember { mutableDoubleStateOf(50.00) }
    var trades by remember { mutableStateOf(listOf<DemoTrade>()) }
    var history by remember { mutableStateOf(listOf<String>()) }
    var nextId by remember { mutableIntStateOf(1) }
    var ticks by remember { mutableIntStateOf(0) }

    LaunchedEffect(running) {
        while (running) {
            delay(3000)
            price += Random.nextDouble(-1.2, 1.2)
            ticks++
            // Demo-only strategy: opens a virtual position every fourth tick.
            if (ticks % 4 == 0 && trades.size < 5) {
                val side = if (Random.nextBoolean()) "BUY" else "SELL"
                val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                trades = trades + DemoTrade(nextId++, side, price, stamp)
            }
            // Virtual positions close after three ticks; result is randomized for simulation.
            if (ticks % 3 == 0 && trades.isNotEmpty()) {
                val closed = trades.first()
                val win = Random.nextBoolean()
                val change = if (win) 0.50 else -0.50
                balance += change
                history = listOf(
                    "#${closed.id} ${closed.side} • ${if (win) "DEMO WIN" else "DEMO LOSS"} • ${if (win) "+" else ""}${"%.2f".format(change)} USD"
                ) + history.take(9)
                trades = trades.drop(1)
            }
        }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("GOLD SCALPER PRO", style = MaterialTheme.typography.headlineSmall)
                Text("SIMULATOR • NOT CONNECTED TO POCKET OPTION", color = MaterialTheme.colorScheme.error)
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Simulated Gold price", style = MaterialTheme.typography.titleMedium)
                        Text("XAUUSD  $${"%.2f".format(price)}", style = MaterialTheme.typography.headlineMedium)
                        Text("Illustrative price only — no live market feed")
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Virtual account balance", style = MaterialTheme.typography.titleMedium)
                        Text("$${"%.2f".format(balance)}", style = MaterialTheme.typography.headlineLarge)
                        Text("Starting demo balance: $50.00")
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { running = true }, enabled = !running, modifier = Modifier.weight(1f)) {
                        Text("START")
                    }
                    OutlinedButton(onClick = { running = false }, enabled = running, modifier = Modifier.weight(1f)) {
                        Text("PAUSE")
                    }
                    OutlinedButton(onClick = {
                        running = false
                        trades = emptyList()
                        history = emptyList()
                        balance = 50.00
                        ticks = 0
                        nextId = 1
                    }, modifier = Modifier.weight(1f)) { Text("RESET") }
                }
                Text(if (running) "Simulator running" else "Simulator paused")
            }
            item {
                Text("Open virtual trades (${trades.size}/5)", style = MaterialTheme.typography.titleLarge)
            }
            if (trades.isEmpty()) {
                item { Text("No open demo trades. Press START to run the simulator.") }
            } else {
                items(trades, key = { it.id }) { trade ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("#${trade.id} ${trade.side} @ ${"%.2f".format(trade.entry)}")
                            Text(trade.openedAt)
                        }
                    }
                }
            }
            item { Text("Recent demo results", style = MaterialTheme.typography.titleLarge) }
            if (history.isEmpty()) item { Text("No simulated results yet.") }
            items(history) { result -> Text(result) }
            item {
                Text(
                    "Important: This app is a practice simulator. Prices and trade outcomes are randomly generated. " +
                    "It does not provide trading signals, connect to a broker, or place Pocket Option orders.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
